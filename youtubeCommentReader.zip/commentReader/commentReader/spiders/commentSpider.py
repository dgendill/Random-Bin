#-------------------------------------------------------------------------------
'''
Name:       YouTube Comment Spider
File Name:  commentSpider.py
Purpose:    Collects YouTube commments.


        *** REQUIREMENTS:

            1. You will need to install Scrapy v.0.12.0.  See the Scrapy site for
            more detailed installation instructions:

                http://doc.scrapy.org/intro/install.html

            2. Python 2.7

            3. The commentReader folder and files.

        *** USAGE:

            Using the terminal/command prompt navigate to the commentReader
            folder and type:

                scrapy crawl youtubeCommentSpider

        *** HOW IT WORKS:

            The spiders must starts on a search page:

            http://www.youtube.com/results?search_query=games&aq=f

            Modify the start_urls variable accordingly.

            From there, it reads the URLs of all videos returned by the search
            and compiles them into a list.  The spider extracts the video ID,
            and visits the video's comment page:

            http://www.youtube.com/comment_servlet?all_comments=1&v=[VIDEO ID]

        *** THE LOG FILE:

            Comments are logged in the text file of your choice.  The log file
            will look something like this...

            <-- PAGE START - http://www.youtube.com/comment_servlet?all_comments=1&v=K3XdTva3hDU -->

            --------------------
            MyCommentNumber: 1
            Page: http://www.youtube.com/comment_servlet?all_comments=1&v=K3XdTva3hDU
            Date: 3 months ago, [Log Created 02Mar2011]
            User: carrielynn9
            User URL: http://www.youtube.com/user/carrielynn9
            Comment: wow, great job by all involved! I am a 911 dispatcher
            Datascore: 1
            --------------------
            MyCommentNumber: 2
            Page: http://www.youtube.com/comment_servlet?all_comments=1&v=K3XdTva3hDU
            Date: 7 months ago, [Log Created 02Mar2011]
            User: alexandreleven
            User URL: http://www.youtube.com/user/alexandreleven
            Comment: he was very lucky to have his cell? phone.
            Datascore: 1
            <-- PAGE END - COMMENT COUNT 2 -->
            <-- PAGE END - http://www.youtube.com/comment_servlet?all_comments=1&v=K3XdTva3hDU -->

            Windows Notepad
        *** INFORMATIONAL RESOURCES

            XPath Tutorial
            http://www.w3schools.com/xpath/xpath_syntax.asp

            Scrapy 0.12 documentation
            http://doc.scrapy.org/index.html

            Python 2.7.1 - Input/Output
            http://docs.python.org/tutorial/inputoutput.html

            Python 2.7.1 - UNICODE Howto
            http://docs.python.org/howto/unicode.html

            Python 2.7.1 - re - Regular Expression Operations
            http://docs.python.org/library/re.html

Author:     Dominick Gendill
Created:    01/03/2011
Copyright:  (c) Dominick Gendill 2011
Licence:    Public Domain
'''
#-------------------------------------------------------------------------------
#!/usr/bin/env python

import re, codecs
from datetime import date
from scrapy.spider import BaseSpider
from scrapy.selector import HtmlXPathSelector
from commentReader.items import CommentReaderItem, UrlItem
from scrapy.http import Request
from scrapy.utils.misc import arg_to_iter

logfileName = "log.txt"

class commentSpider(BaseSpider):
    name = "youtubeCommentSpider"
    allowed_domains = ["youtube.com","www.youtube.com"]
    start_urls = ["http://www.youtube.com/results?search_query=911&aq=f"]

    def parse(self, response):
        hxs = HtmlXPathSelector(response)
        nodes = hxs.select("//div[@class='result-item-main-content']/h3")
        items = []

        for node in nodes:
            item = UrlItem()
            item['url'] = node.select('a/@href').extract()[0]
            # I only want URLs with the format /watch?v=
            if re.match(r'\/watch\?v=',item['url']) is None:
                continue
            # If there is a match, ending will contain what matched in the
            # [brackets]
            ending = node.re('v=[a-zA-Z\-0-9]+');
            if len(ending) is 0:
                item['commentUrl'] = "None"
            else:
                item['commentUrl'] = "http://youtube.com/comment_servlet?all_comments=1&" + ending.pop()
            item['title'] = node.select('a/@title').extract()[0]
            items.append(item)
        requests = []
        for item in items:
            requests.extend(arg_to_iter(Request(item['commentUrl'],self.parseComments)))
        # add the requests to the item list
        items.extend(requests)
        return items

    def parseComments(self,response):
        hxs = HtmlXPathSelector(response)
        nodes = hxs.select("//div[@class='comment-text']")
        url = response.url
        f = codecs.open(logfileName, encoding='utf-8', mode='a')
        f.write("<-- PAGE START - " + url + " -->\r\n\r\n")
        commentCount = 0

        for node in nodes:
            try:
                comment = node.select("p/text()").extract()[0]
                user = node.select("../../@data-author").extract()[0]
                datascore = node.select("../../@data-score").extract()[0]
                time = node.select("../../div[@class='metadata']/span[@class='time']/text()").extract()[0]
                today = date.today()
                today = today.strftime('%d%b%Y')
                commentCount = commentCount + 1
            except IndexError:
                comment = "<-- NONE -->"
                user = "<-- NONE -->"
                datascore = "<--NONE-->"

            f.write("--------------------\n")
            f.write("MyCommentNumber: " + str(commentCount) + "\r\n")
            f.write("Page: " + url + "\r\n")
            f.write("Date: " + time + ", [Log Created " + today + "]\r\n")
            f.write("User: " + user + "\r\n")
            f.write("User URL: http://www.youtube.com/user/" + user + "\r\n")
            f.write("Comment: " + comment + "\r\n")
            f.write("Datascore: " + datascore + "\r\n\r\n")

        f.write("<-- PAGE END - COMMENT COUNT " + str(commentCount) + " -->\r\n")
        f.write("<-- PAGE END - " + url + " -->\r\n\r\n\r\n")
        f.close()



