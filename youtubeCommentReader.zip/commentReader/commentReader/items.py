# Define here the models for your scraped items
#
# See documentation in:
# http://doc.scrapy.org/topics/items.html

from scrapy.item import Item, Field

class CommentReaderItem(Item):
    user = Field()
    date = Field()
    comment = Field()
    # define the fields for your item here like:
    # name = Field()
    pass

class UrlItem(Item):
    url = Field()
    title = Field()
    commentUrl = Field()
    pass